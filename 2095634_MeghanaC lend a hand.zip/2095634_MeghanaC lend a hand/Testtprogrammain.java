package project1;

public class Testtprogrammain {
	public static void main(String[] args) {
		int count =5;
		welcomemessagel message=new welcomemessagel();
		do{
			message.printMessage();
			count--;}
		while(count>0);
		}
	}


