package project1;

public class MainClass {
	public static void  main(String args[]) {
		Studentt student = new Studentt();
		student.setRollNo("21");
		student.setMark1(65);
		student.setMark2(85);
		student.setMark3(40);
		ResultCalculator calculator = new ResultCalculator();
		result result=calculator.calculateResult(student);
		System.out.println("Student Results Roll no :" +result.getRollNo()+ "Result :" + result.getGrade());
	}

}
