package project1;

public class Employemain {
public static void main(String[] args) {
	Employe employee=new Employe();
	System.out.println("The Id of the employee is" + employee.empId);
	System.out.println("The salary of the employee is" +employee.empSalary);
	System.out.println("The percentage of taxthe employeeneeds"+"to pay is"+ employee.empTax);
	System.out.println("The total number of working days is" +employee.daysofWork);
}
}
