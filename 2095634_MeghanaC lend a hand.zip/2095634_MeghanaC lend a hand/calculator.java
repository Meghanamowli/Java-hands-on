package project1;

public class calculator {
int num1;
int num2;

void addition() {
	int num3=num1 + num2;
	System.out.println("The sum of the" + "two numbers is : " + num3); } 
	
void subtraction() {
		int num3=num1 - num2;
		System.out.println("The difference between the" +"two numbers is" +num3);}

	void printSmaller () {
		int num3=(num1<num2) ? num1:num2;
		System.out.println("The smallest of the" +" two numbers is" +num3);}
}

