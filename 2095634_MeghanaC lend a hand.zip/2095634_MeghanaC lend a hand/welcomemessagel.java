package project1;

public class welcomemessagel {
	void printMessage() {
		System.out.println("Welcome all");
	}

}
