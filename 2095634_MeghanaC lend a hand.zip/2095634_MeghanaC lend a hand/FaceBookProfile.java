package project1;

public class FaceBookProfile {
	private String maritalStatus;
	private String phoneNumber;
	private int age;
	
	public String getMaritalStatus() {
		return maritalStatus;
	}
	public void setMaritalStatus(String maritalStatus){
		this.maritalStatus = maritalStatus;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
			}
	public int getAge(){
		return age;
	}
	public void setAge(int age){
		this.age=age;
	}

}
