package project1;

public class calculatormain {
public static void main (String[] args) {
	calculator calculator=new calculator ();
	calculator.num1=11;
	calculator.num2=17;
	calculator.addition();
	calculator.subtraction();
	calculator.printSmaller();
	
}
}
