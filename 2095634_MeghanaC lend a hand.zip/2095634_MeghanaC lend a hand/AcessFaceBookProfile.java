package project1;

public class AcessFaceBookProfile {
public static void  main(String args[]){
	FaceBookProfile accessProfile = new FaceBookProfile();
	accessProfile.setMaritalStatus("Single");
	accessProfile.setAge(20);
	accessProfile.setPhoneNumber("99472 74512");
	
	System.out.println(
			"Marital Status : "+accessProfile.getMaritalStatus() +
			"Age :" + accessProfile.getAge() +
			"Phone Number : " + accessProfile.getPhoneNumber());		
	
}
}
