
class Welcome2{
	void printmessage() {
		System.out.println("Welcome All");
	}
}


public class ForProblem {

	public static void main(String[] args) {
		int c=5;
		Welcome2 we=new Welcome2();
		for(c=0;c<5;c++){
			we.printmessage();
		}

	}

}
