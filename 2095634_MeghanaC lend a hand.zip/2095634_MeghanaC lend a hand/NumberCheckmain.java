package project1;

public class NumberCheckmain {
	public static void main(String[] args){
		NumberCheck check = new NumberCheck();
		check.displayBigNumber(11,10,7);
}
}
