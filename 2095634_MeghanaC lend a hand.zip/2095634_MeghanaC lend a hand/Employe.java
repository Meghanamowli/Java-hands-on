package project1;

public class Employe {
long empId=345;
double empSalary=2325.50;
float empTax=9.5f;
int daysofWork=24;
void calculatePF() {
	float pfRate=10.5f;
	System.out.println("The pf rate of the employee is " +pfRate);
}
}
  