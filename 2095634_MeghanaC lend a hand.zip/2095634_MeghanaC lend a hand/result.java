package project1;

public class result {
	private String rollNo;
	private String grade;
	
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade  = grade;
	}

	public void setRollNo(String rollNo) {
		this.rollNo = rollNo;
	}
	public String getRollNo() {
		return rollNo;
	}
}
