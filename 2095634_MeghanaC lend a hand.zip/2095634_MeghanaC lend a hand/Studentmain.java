package project1;

	class StudentMain{
		  public static void main(String args[]){
			  student student =new student();
			  student.registrationId=1290;
			  student.displayRegistrationId();
		  }
	  }

	

	