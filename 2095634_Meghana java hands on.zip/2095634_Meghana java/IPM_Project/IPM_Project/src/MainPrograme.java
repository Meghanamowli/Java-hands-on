
public class MainPrograme {

	public static void main(String[] args) {
		Employee employee = new Employee();
		employee.calculatePF();
	}

}

