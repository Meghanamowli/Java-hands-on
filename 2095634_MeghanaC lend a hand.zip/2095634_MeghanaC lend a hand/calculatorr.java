package project1;

public class calculatorr {
	int num1;
	int num2;

	void bitwiseAND() {
		int num3=num1 + num2;
		System.out.println("The Bitwise AND of" + "two numbers is : " + num3); } 
		
	void bitwiseOR() {
			int num3=num1 - num2;
			System.out.println("The Bitwise OR of" +"two numbers is" +num3);}

		void bitwiseXOR () {
			int num3=num1 ^ num2;
			System.out.println("The Bitwise XOR of" +" two numbers is" + num3);}
		
		void bitwiseNOT () {
			int num3=~num1;
			System.out.println("The Bitwise NOT of" +" two numbers is" + num3);}
		
		
	}

