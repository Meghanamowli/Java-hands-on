
public class Circle extends Shape {
	public double calculateArea() {
		double a=3.14*9*9;
		System.out.println("the area of the circle is: "+a);
		return a;
	}

}
