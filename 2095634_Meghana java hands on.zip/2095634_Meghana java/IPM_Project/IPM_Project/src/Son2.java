
public class Son2 extends Father {

	    public void methodC() {
	        System.out.println("method of Class Son2");
	    }
	}
