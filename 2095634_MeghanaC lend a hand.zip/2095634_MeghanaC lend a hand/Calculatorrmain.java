package project1;

public class Calculatorrmain {
	public static void main (String[] args) {
		calculatorr calculatorr=new calculatorr ();
		calculatorr.num1=15;
		calculatorr.num2=5;
		calculatorr.bitwiseAND ();
		calculatorr.bitwiseOR();
		calculatorr.bitwiseXOR();
	}		

}
