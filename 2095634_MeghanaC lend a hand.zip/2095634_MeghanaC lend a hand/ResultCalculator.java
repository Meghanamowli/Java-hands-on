package project1;

public class ResultCalculator {
	public result calculateResult(Studentt studentt) {
		int total = studentt.getMark1() + studentt.getMark2 () + studentt.getMark3 ();
		int average = total / 3;
		project1.result result = new result();
		result.setRollNo(studentt.getRollNo());
		if (average > 40) {
			result.setGrade("Pass");
		}else{
			result.setGrade("Fail");
	}
	return result;

}
}