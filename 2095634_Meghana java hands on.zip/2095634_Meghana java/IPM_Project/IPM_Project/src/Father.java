
public class Father {
	    public void methodA() {
	        System.out.println("method of Class Father");
	    }

}
