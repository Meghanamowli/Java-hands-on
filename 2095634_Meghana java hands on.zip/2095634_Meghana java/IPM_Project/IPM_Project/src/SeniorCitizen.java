
public class SeniorCitizen extends BankAccount {
	void applyFixedDeposit() {
		super.interestRate=10.5;
	}

}
