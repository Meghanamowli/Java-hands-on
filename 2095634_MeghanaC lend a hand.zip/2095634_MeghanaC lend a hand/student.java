package project1;

 class student {
	              public int registrationId =0;
	              void displayRegistrationId(){
	         				System.out.println("The student registration Id is"+ registrationId);
 }
}
 